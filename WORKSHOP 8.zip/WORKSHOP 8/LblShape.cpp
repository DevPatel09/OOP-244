/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/


#define _CRT_SECURE_NO_WARNINGS

//include headerfiles
#include <iostream>
#include <cstring>
#include <string>
#include "LblShape.h"


//namespace
using namespace std;
namespace sdds
{
    //label function
    const char* LblShape::label() const
    {
        return m_label;
    }


    //LblShape function
    LblShape::LblShape(const char* label)
    {
        if (label && label[0] != '\0')
        {
            m_label = new char[strlen(label) + 1];
            strcpy(m_label, label);
        }
    }

    //Destructor
    LblShape::~LblShape()
    {
        if (m_label)
        {
            delete[] m_label;
            m_label = nullptr;
        }
    }

    //getSpecs function
    void LblShape::getSpecs(std::istream& is)
    {
        //deleting memory
        delete[] m_label;
        string label;



        getline(is, label, ',');
        m_label = new char[strlen(label.c_str()) + 1];
        strcpy(m_label, label.c_str());
    }

}