/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/

//introducing header-guard
#ifndef RECTANGLE_H_HEADERFILE
#define RECTANGLE_H_HEADERFILE

//inlcude headerfiles
#include "LblShape.h"


//namespace
namespace sdds
{

    //inheriting LblShape in Rectangle as public
    class Rectangle : public LblShape
    {


        unsigned int m_width{ 0 };
        unsigned int m_height{ 0 };
    
        //Public
    public:
        Rectangle() {}
        Rectangle(const char* label, int width, int height);
        virtual ~Rectangle() {}

        void getSpecs(std::istream& is);
        void draw(std::ostream& os) const;
    };

}


#endif //RECTANGLE_H_HEADERFILE