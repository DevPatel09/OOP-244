/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/

#ifndef Lblshape_H_HEADERFILE
#define Lblshape_H_HEADERFILE



#include "Shape.h"


namespace sdds
{


    class LblShape : public Shape
    {
        char* m_label = nullptr;


    protected:
        const char* label() const;


    public:

        LblShape() {}
        LblShape(const char* label);

        virtual ~LblShape();
        void getSpecs(std::istream& is);

        LblShape(const LblShape& src) = delete;
        LblShape& operator=(const LblShape& src) = delete;

    };
}
#endif //Lblshape_H_HEADERFILE