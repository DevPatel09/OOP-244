/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/


//include headerfiles
#include <iostream>
#include "Line.h"


//namespace
using namespace std;
namespace sdds


{
    //inherenting function
    Line::Line(const char* label, int length) : LblShape(label)
    {
        if (length > 0)
        {
            m_length = length;
        }
    }


    //getSpecs function
    void Line::getSpecs(std::istream& is)
    {

//Local variables

        int length;
        bool ignore = false;

        //do-while loop
        do
        {
            LblShape::getSpecs(is);
            is >> length;

            if (!is)
            {
                is.clear();
                is.ignore(32767, '\n');
            }

            else
            {
                is.ignore();
                m_length = length;

                ignore = true;
            }

            //condition
        } while (!ignore);

    }


    //draw function that will accept ostream variable
    void Line::draw(std::ostream& os) const
    {

        //if condition 
        if (m_length > 0 && LblShape::label())
        {


            os << LblShape::label() << endl;
            os.width(m_length);
            os.fill('=');
            os << '=';


        }
    }
}