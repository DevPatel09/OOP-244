/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/



//include headerfiles
#include <iostream>
#include <cstring>
#include "Rectangle.h"

//namespace
using namespace std;

namespace sdds
{
    //parameterised constructor
    Rectangle::Rectangle(const char* label, int width, int height) : LblShape(label)
    {
        int widthCheck = strlen(LblShape::label()) + 2;

        if (width > widthCheck && height > 3)
        {
            //assigning values
            m_width = width;
            m_height = height;
        }
    }

    //getSpecs function
    void Rectangle::getSpecs(std::istream& is)
    {
        bool ignore = false;
        char c;

        int height;
        int width;

        do
        {
            LblShape::getSpecs(is);
            is >> width >> c >> height;

            if (!is)
            {
                is.clear();
                is.ignore(32767, '\n');
            }
            else
            {
                is.ignore();
                m_width = width;
                m_height = height;
                ignore = true;
            }

        } while (!ignore);
    }

    //draw function
    void Rectangle::draw(std::ostream& os) const
    {


        if (m_width > 0 && m_height >> 0)
        {
            os << '+';
            os.width(m_width - 2);
            os.fill('-');
            os << '-' << '+' << endl;

            os << '|';
            os.width(m_width - 2);
            os.fill(' ');
            os << left << LblShape::label() << '|' << endl;

            for (unsigned int i = 0; i < (m_height - 3); i++)
            {
                os << '|';
                os.width(m_width - 2);
                os.fill(' ');
                os << ' ' << '|' << endl;
            }


            os << '+';
            os.width(m_width - 2);
            os.fill('-');
            os << '-' << '+';
        }


    }
}