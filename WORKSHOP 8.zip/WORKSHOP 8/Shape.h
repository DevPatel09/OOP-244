/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/


//Introducing header-guard
#ifndef SHAPE_H_HEADERFILE
#define SHAPE_H_HEADERFILE


//include headerfiles
#include <iostream>

//namespace
namespace sdds
{
    //Class named Shape
    class Shape
    {
        //Public
    public:
        virtual ~Shape() {}
        virtual void draw(std::ostream& os) const = 0;
        virtual void getSpecs(std::istream& is) = 0;
    };

    //Operator overloading functions
    std::ostream& operator<<(std::ostream& os, const Shape& src);
    std::istream& operator>>(std::istream& is, Shape& src);
}

#endif //SHAPE_H_HEADERFILE 