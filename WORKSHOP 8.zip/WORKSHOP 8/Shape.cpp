/*     WORKSHOP-8
//Name : Dev Kshitij Patel
Student ID : 142979228
Student Email ID : dkpatel59@myseneca.ca
Section: ZCC
*/

//Include headerfiles
#include <iostream>
#include "Shape.h"


//Namespace std
using namespace std;


//Namespace sdds
namespace sdds
{
    //<< (Ostream) operator
    ostream& operator<<(ostream& os, const Shape& src)
    {
        src.draw(os);
        //Return os
        return os;
    }

    //>> (Istream) operator
    istream& operator>>(istream& is, Shape& src)
    {
        src.getSpecs(is);
        //Return is
        return is;
    }
}