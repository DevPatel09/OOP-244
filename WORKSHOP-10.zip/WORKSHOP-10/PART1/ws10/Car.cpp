/*
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/



#define _CRT_SECURE_NO_WARNINGS


#include <iostream>
#include <cstring>

#include "Car.h"
using namespace std;


namespace sdds {
   Car::Car(const char* plate , const char* makeModel ) {


      strncpy(m_plate, plate, 8);
      m_plate[8] = 0;
      strncpy(m_makeModel, makeModel, 40);
      m_makeModel[40] = 0;;
   }

   std::ostream& Car::display(std::ostream& os)const {
      return os << m_plate << " " << m_makeModel;


   }


   bool Car::operator==(const char* mmSubstr)const {
      return strstr(m_makeModel, mmSubstr) != nullptr;
   }
}