/*
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/


#include <iostream>
#include "Displayable.h"


using namespace std;
namespace sdds {


   ostream& operator<<(ostream& os, const Displayable& c) {
      return c.display(os);
   }
}