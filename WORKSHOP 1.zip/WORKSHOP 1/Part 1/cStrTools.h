/*Name - Dev Kshitij Patel
Student - 142979228
E-mail - dkpatel59@myseneca.ca
Decelaration - I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assigments*/
#pragma once
#ifndef SDDS_cStrTools_H // replace with relevant names
#define SDDS_cStrTools_H
namespace sdds {
	char toLower(char ch);
	int strCmp(const char* s1, const char* s2);

	int strnCmp(const char* s1, const char* s2, int len);
	void strCpy(char* des, const char* src);
	int strLen(const char* str);
	const char* strStr(const char* str, const char* find);
	int isAlpha(char ch);
	int isSpace(char ch);
	void trim(char word[]);
	void toLowerCaseAndCopy(char des[], const char source[]);

}
#endif
