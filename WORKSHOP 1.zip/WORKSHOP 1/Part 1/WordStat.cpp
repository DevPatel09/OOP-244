/*Name - Dev Kshitij Patel
Student - 142979228
E-mail - dkpatel59@myseneca.ca
Decelaration - I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assigments*/
#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <iostream>
#include <iomanip>
#include "Word.h"

using namespace sdds;
using namespace std;
int main() {
	char filename[256];
	programTitle();
	cout << "Enter filename: ";
	cin >> filename;
	wordStats(filename);
	return 0;
}
