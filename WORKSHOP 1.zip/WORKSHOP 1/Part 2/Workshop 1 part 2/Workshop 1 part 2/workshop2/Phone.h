/******************************************************************************
                    Workshop - #1 (Part-2)
Name : Dev Kshitij Patel
Student ID#: 142979228
Email : dkpatel59@myseneca.ca
Section : ZCC
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
******************************************************************************/
#pragma once
#ifndef SDDS_Phone_H 
#define SDDS_Phone_H

//Macrodirectives
#define MAXIMUM_NAME 50
#define MAXIMUM_LENGTH 20

//Phone_Directory Structure
struct Phone_Directory {
	char Person_Name[MAXIMUM_NAME + 1];
	char Postal_Code[MAXIMUM_LENGTH + 1];
	char Starting_Letters[MAXIMUM_LENGTH + 1];
	char Phone_Number[MAXIMUM_LENGTH + 1];
};

namespace sdds {

	// runs the phone directory application
	void phoneDir(const char* programTitle, const char* fileName);
	
	
}
#endif