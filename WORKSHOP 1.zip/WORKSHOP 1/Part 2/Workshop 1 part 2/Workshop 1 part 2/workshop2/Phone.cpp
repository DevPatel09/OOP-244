/******************************************************************************
					Workshop - #1 (Part-2)>
Name : Dev Kshitij Patel
Student ID#:142979228
Email : dkpatel59@myseneca.ca
Section : ZCC
Authenticity Declaration:
I declare this submission is the result of my own work and has not been
shared with any other student or 3rd party content provider. This submitted
piece of work is entirely of my own creation.
******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS

//Header Files
#include <iostream>
#include <string.h>
#include "Phone.h"
#include "cStrTools.h"

using namespace std;
namespace sdds
{
	//Function
	void phoneDir(const char* programTitle, const char* fileName)
	{
		//Data-types
		Phone_Directory Ph_Dir;
		char Name[MAXIMUM_NAME + 1];
		int flag = 1; 
		const char* filePtr = nullptr;
		char Small[MAXIMUM_NAME + 1];
		
		//Displaying output
		cout << programTitle << " phone direcotry search" << endl;
		cout << "-------------------------------------------------------" << endl;

		//Assigning value of file pointer to NULL then reassign and defining the mode.
		FILE* fptr = NULL;
		fptr = fopen(fileName, "r");

		if (fptr != NULL) {
			do {
				//Displaying the output
				cout << "Enter a partial name to search (no spaces) or enter '!' to exit" << endl;
				cout << "> ";
				cin >> Name;

				//calling toLowerCaseAndCopy function
				toLowerCaseAndCopy(Name, Name);

				//If condition 
				if (strCmp(Name, "!") == 0) {
					//Displaying the output
					cout << "Thank you for using " << programTitle << " directory." << endl;
					flag = 0;
				}

				//else condition
				else 
				{
					//while loop
					while (fscanf(fptr, "%[^\t]\t%s\t%s\t%s\n", Ph_Dir.Person_Name, Ph_Dir.Postal_Code, Ph_Dir.Starting_Letters, Ph_Dir.Phone_Number) != EOF)
					{
						toLowerCaseAndCopy(Small, Ph_Dir.Person_Name);
						filePtr = strStr(Small, Name);

						//if condition to check what if the file pointer is not null
						if (filePtr != NULL)
						{
							//Displaying the output
							cout << Ph_Dir.Person_Name << ": (" << Ph_Dir.Postal_Code << ") " << Ph_Dir.Starting_Letters << "-" << Ph_Dir.Phone_Number << endl;

						}
					}
					fseek(fptr, 0, SEEK_SET);
				}
			} while (flag);

			//Closing the file pointer
			fclose(fptr);
		}
		else
		{
			//Displaying the output
			cout << fileName << " file not found!" << endl;
			cout << "Thank you for using Broken Phone Book directory." << endl;
		}

	}
	
}
