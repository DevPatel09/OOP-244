/* WORKSHOP-9 (Part-1)
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/
#define _CRT_SECURE_NO_WARNINGS

//header files 
#include <iostream>
#include <cstring>
#include "Graduate.h"

//namespace 
namespace sdds
{
    // setEmpty function initializes the dynamic pointers to nullptr
    void Graduate::setEmpty()
    {
        m_thesis = nullptr;
        m_supervisor = nullptr;
    }

    // Default constructor
    Graduate::Graduate()
    {
    }

    // Parameterized constructor
    Graduate::Graduate(const char* name, size_t age, const char* thesis, const char* supervisor)
        : Student(name, age)
    {
        setEmpty(); // Initialize dynamic pointers to nullptr
        alocpy(m_thesis, thesis); // Allocate memory and copy thesis
        alocpy(m_supervisor, supervisor); // Allocate memory and copy supervisor
    }

    // Destructor
    Graduate::~Graduate()
    {
        delete[] m_thesis; // Deallocate memory for thesis
        delete[] m_supervisor; // Deallocate memory for supervisor
    }

    // Copy constructor
    Graduate::Graduate(const Graduate& src) : Student(src)
    {
        setEmpty(); // Initialize dynamic pointers to nullptr
        operator=(src); // Call the copy assignment operator
    }

    // Copy assignment operator
    Graduate& Graduate::operator=(const Graduate& gra)
    {
        // Check for self-assignment
        if (this != &gra)
        {
            Student::operator=(gra); // Call the base class assignment operator
            alocpy(m_thesis, gra.m_thesis); // Allocate memory and copy thesis
            alocpy(m_supervisor, gra.m_supervisor); // Allocate memory and copy supervisor
        }
        // Return the current object
        return *this;
    }

    // Display function to show the graduate student's information
    void Graduate::display() const
    {
        Student::display(); // Call the display function of the base class
        // Check if thesis and supervisor information is available
        if (m_thesis != nullptr && m_supervisor != nullptr)
        {
            // Display the thesis title and supervisor
            std::cout << "Thesis Title: " << m_thesis << std::endl;
            std::cout << "Supervisor: " << m_supervisor << std::endl;
            std::cout << "---------------------------------------------" << std::endl;
        }
    }
}
