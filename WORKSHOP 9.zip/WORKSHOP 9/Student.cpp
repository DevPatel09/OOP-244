/* WORKSHOP-9 (Part-1)
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include "Student.h"

namespace sdds {
    // Function to set the object to an empty state
    void Student::setEmpty()
    {
        m_name = nullptr;
        m_age = 0;
    }

    // Conversion operator to check if the object is in a valid state
    Student::operator bool() const
    {
        return m_name && m_name[0] != '\0';
    }

    // Function to allocate memory and copy a string
    void Student::alocpy(char*& destination, const char* source)
    {
        // Check if the source is not null and not an empty string
        if (source && source[0] != '\0') {
            delete[] destination; // Deallocate existing memory
            destination = nullptr; // Set destination to nullptr
            destination = new char[strlen(source) + 1]; // Allocate memory
            strcpy(destination, source); // Copy the source string
        }
        else
        {
            destination = nullptr; // Set destination to nullptr if source is null or empty
        }
    }

    // Default constructor
    Student::Student() {};

    // Parameterized constructor
    Student::Student(const char* name, size_t age) {
        // Check if the name is not null and not an empty string
        if (name && name[0] != '\0') {
            alocpy(m_name, name); // Allocate memory and copy the name
            m_age = age; // Set the age
        }
        else
        {
            setEmpty(); // Set the object to an empty state if the name is null or empty
        }
    }

    // Copy constructor
    Student::Student(const Student& stu) {
        operator=(stu); // Call the copy assignment operator
    }

    // Copy assignment operator
    Student& Student::operator=(const Student& stu) {
        // Check for self-assignment
        if (this != &stu) {
            alocpy(m_name, stu.m_name); // Allocate memory and copy the name
            m_age = stu.m_age; // Copy the age
        }
        return *this;
    }

    // Destructor
    Student::~Student() {
        delete[] m_name; // Deallocate memory for the name
    }

    // Display function to show the student's information
    void Student::display() const {
        if (m_name) {
            std::cout << "Name: " << m_name << std::endl; // Display the name
            std::cout << "Age: " << m_age << std::endl; // Display the age
        }
    }
}
