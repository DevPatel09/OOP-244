/* WORKSHOP-9 (Part-1)
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/


#ifndef SDDS_STUDENT_H_HEADER_GUARD
#define SDDS_STUDENT_H_HEADER_GUARD

//namespace
namespace sdds
{
    //Student class
    class Student
    {
        //Data members which is private 
        char* m_name{ nullptr };
        int m_age{ 0 };
        void setEmpty();

     //Protected
    protected:
        //Operator function
        operator bool()const;

        //alocpy function
        void alocpy(char*& destination, const char* source);

        //Public
    public:
        //constructor
        Student();
        Student(const char* name, size_t age);
        Student(const Student& student);

        //= operator function
        Student& operator=(const Student& student);

        //Virtual function which is a destructor
        virtual ~Student();
        
        //Display function
        void display() const;
    };
}
#endif 