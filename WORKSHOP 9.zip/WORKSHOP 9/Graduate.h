/* WORKSHOP-9 (Part-1)
Name: Dev Kshitij Patel
Student ID: 142979228
Student Email ID: dkpatel59@myseneca.ca
Section: ZCC
*/

#ifndef SDDS_GRADUATE_H_HEADER_GUARD
#define SDDS_GRADUATE_H_HEADER_GUARD

//Include header files
#include "Student.h"

//namespacce
namespace sdds
{
    //Graduate class which inherent publically from Student class
    class Graduate : public Student
    {
        //Data members which is private
        char* m_thesis{ nullptr };
        char* m_supervisor{ nullptr };
        void setEmpty();

    //Public 
    public:
        //constructor
        Graduate();
        Graduate(const char* name, size_t age, const char* thesis, const char* supervisor);
        Graduate(const Graduate& graduate);

        //Virtual function which is a destructor too
        virtual ~Graduate();

        //= operator function
        Graduate& operator=(const Graduate& graduate);

        //display function
        void display() const;
    };
}
#endif 