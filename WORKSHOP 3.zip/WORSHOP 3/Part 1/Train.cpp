/*Name: Dev Kshitij Patel
* Student ID number: 142979228
* Student Email ID: dkpatel59@myseneca.ca
* Section: ZCC
*/

/***********************************************************************
// OOP244 Workshop #3 lab (part 1): tester program
//
// File  main.cpp
// Version 1.0
// Author   Cornel Barna, Fardad Soleimanloo
// Description
//
// Revision History
// -----------------------------------------------------------
//I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
***********************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include "Train.h"
#include <cstring>
#include <iostream>

namespace sdds {
 

    Train::Train() {
        Name = nullptr;
        People = -1;
        Time_Of_Departure = -1;
    }

    Train::~Train() {
        finalize();
    }

    void Train::initialize() {
        finalize();
        Name = nullptr;
        People = -1;
        Time_Of_Departure = -1;
    }


    bool Train::validTime(int value) const {
        int minutes = value % 100;
        return (value >= MIN_TIME && value <= MAX_TIME && minutes <= 59);
    }


    bool Train::validNoOfPassengers(int value) const {
        return (value > 0 && value < MAX_NO_OF_PASSENGERS);
    }

    void Train::set(const char* name) {
        finalize();
        if (name && name[0] != '\0') {
            this->Name = new char[strlen(name) + 1];
            strcpy(this->Name, name);
        }
        else {
            this->Name = nullptr;
        }
    }

    void Train::set(int noOfPassengers, int departure) {
        if (validNoOfPassengers(noOfPassengers) && validTime(departure)) {
            People = noOfPassengers;
            Time_Of_Departure = departure;
        }
        else {
            People = -1;
            Time_Of_Departure = -1;
        }
    }

    void Train::set(const char* name, int noOfPassengers, int departure) {
        set(name);
        set(noOfPassengers, departure);
    }

    void Train::finalize() {
        delete[] Name;
        Name = nullptr;
    }

    bool Train::isInvalid() const {
        return (People == -1 || Time_Of_Departure == -1 || !Name);
    }

    int Train::noOfPassengers() const {
        return People;
    }

    const char* Train::getName() const {
        return Name;
    }

    int Train::getDepartureTime() const {
        return Time_Of_Departure;
    }

    void Train::display() const {
        if (isInvalid()) {
            std::cout << "Train in an invalid State!" << std::endl;
        }
        else {
            std::cout << "NAME OF THE TRAIN:    " << getName() << std::endl;
            std::cout << "NUMBER OF PASSENGERS: " << noOfPassengers() << std::endl;
            std::cout << "DEPARTURE TIME:       " << getDepartureTime() << std::endl;
     
        }
    }
}

